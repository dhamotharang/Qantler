import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-circular-template',
  templateUrl: './circular-template.component.html'
})
export class CircularTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
