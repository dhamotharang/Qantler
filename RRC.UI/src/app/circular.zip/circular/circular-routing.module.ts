import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CircularListComponent } from './container/circular-list/circular-list.component';
import { IncomingCircularFormComponent } from './container/incoming-circular-form/incoming-circular-form.component';
import { CircularTemplateComponent } from './components/circular-template.component';
const routes: Routes = [{
  path: '', component:CircularTemplateComponent,
  children: [
    { path: 'circular-list', component: CircularListComponent },
    { path: 'circular-create', component: IncomingCircularFormComponent, data: { title: 'Create' } },
    { path: 'Circular-view/:id', component: IncomingCircularFormComponent, data: { title: 'View' } },
    { path: 'Circular-edit/:id', component: IncomingCircularFormComponent, data: { title: 'Edit' } },
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CircularRoutingModule { }
