import { Component, OnInit, ViewChild, TemplateRef, ChangeDetectorRef } from '@angular/core';
import { BsDatepickerConfig } from 'ngx-bootstrap';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CreateCircularModal } from './create-circular.modal';
//import { SampleData } from './sampleDB';
import 'tinymce';
import { async } from 'q';
import { DatePipe } from '@angular/common';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ModalComponent } from '../../../modal/modalcomponent/modal.component';
import { SuccessComponent } from '../../../modal/success-popup/success.component';
import { CommonService } from '../../../common.service';
import { CircularService } from '../../../circular.service';

declare var tinymce: any;

@Component({
  selector: 'app-circular-form',
  templateUrl: './incoming-circular-form.component.html',
  styleUrls: ['./incoming-circular-form.component.scss']
})
export class IncomingCircularFormComponent implements OnInit {
  bsConfig: Partial<BsDatepickerConfig>;
  @ViewChild('template') template: TemplateRef<any>;
  bsModalRef: BsModalRef;
  createCircular: CreateCircularModal = new CreateCircularModal();
  screenStatus = 'Create';
  displayStatus : any = 'CREATION';
  masterData: any;
  circularData: any = {
    HistoryLog: []
  };
  //circularData: any;
  status = '';
  user = [];//this.masterData.data.user;
  department = [];//this.masterData.data.department;
  priorityList = ['High', 'Medium', 'Low', 'Very low'];
  attachmentFiles = [];
  createdTime: string;
  createdDate: string;


  dropdownSettings: any;

  colorTheme = 'theme-green';
  incomingcircular = {
    CircularID: 0,
    ReferenceNumber: '',
    Title: '',
    SourceOU: '',
    SourceName: '',
    DestinationOU: [],
    ApproverName: 0,
    ApproverDepartment: 0,
    Details: '',
    Priority: '',
    Comments: '',
    Attachments: [],
    AttachmentName: '',
    DeleteFlag: '',
    CreatedBy: '',
    UpdatedBy: '',
    HistoryLog: [],
    CreatedDateTime: new Date(),
    UpdatedDateTime: '',
    Status: 0,
  }
  img_file: any;
  message: any;
  currrentUser: any = JSON.parse(localStorage.getItem('User'));
  attachments: any = [];
  userDestination: any;
  userReceiver: any;
  commonMes: any;
  DestinationDepartmentId: any[];
  constructor(private changeDetector: ChangeDetectorRef, public common: CommonService, public router: Router, route: ActivatedRoute, public datepipe: DatePipe,
    private modalService: BsModalService, private circularService: CircularService) {
    route.url.subscribe(() => {
      console.log(route.snapshot.data);
      this.screenStatus = route.snapshot.data.title;
    });
    route.params.subscribe(param => {
      var id = +param.id;
      if (id > 0)
        this.loadData(id, this.currrentUser.id);
    });
    this.circularService.getCircular('Circular', 0, 0).subscribe((data: any) => {
      this.department = data.OrganizationList;
    });
    if(this.screenStatus == 'Create'){
      this.displayStatus = 'CREATION';
    }
    if(this.screenStatus == 'View'){
      this.displayStatus = 'VIEW';
    }
    if(this.screenStatus == 'Edit'){
      this.displayStatus = 'EDIT';
    }
  }

  async loadData(id, userid) {
    await this.circularService.getCircular('Circular', id, userid).subscribe((data: any) => {
      this.circularData = data;
      if (this.screenStatus == 'View' || this.screenStatus == 'Edit') {
        let that = this;
        this.status = this.circularData.M_LookupsList;
        var date = this.incomingcircular.CreatedDateTime;
        this.incomingcircular.CreatedDateTime = new Date(date);
        this.setData(this.circularData);
        this.bottonControll();
      } else {
        this.initPage();
        this.bottonControll();
      }
    });
  }

  setData(data) {
    this.getDestUserList(+data.ApproverDepartmentId);
    //this.getRecvPrepareUserList(data.DestinationDepartmentID);
    this.incomingcircular.CircularID = data.CircularID;
    this.incomingcircular.ReferenceNumber = data.ReferenceNumber
    this.incomingcircular.Title = data.Title;
    this.incomingcircular.SourceOU = data.SourceOU;
    this.incomingcircular.SourceName = data.SourceName;
    
    const DestinationOU = [];
    const DestinationUsername = [];
    data.DestinationDepartmentID.forEach((department, index) => {
      DestinationOU.push(department.CircularDestinationDepartmentID);
    });
    this.incomingcircular.DestinationOU = DestinationOU;
    this.DestinationDepartmentId = this.incomingcircular.DestinationOU;
    // data.DestinationUsernameID.forEach((user,index)=>{
    //   DestinationUsername.push(user.MemoDestinationUsersID);
    // });
    //this.incomingcircular.DestinationUsername = DestinationUsername;
    this.incomingcircular.ApproverName = data.CurrentApprover[0].ApproverId; //Check this set
    this.incomingcircular.ApproverDepartment = +data.ApproverDepartmentId; //check this set
    this.incomingcircular.Details = data.Details;
    this.incomingcircular.Priority = data.Priority;
    this.incomingcircular.CreatedBy = data.CreatedBy;
    this.attachments = data.Attachments;
    this.incomingcircular.HistoryLog = data.HistoryLog;

    this.incomingcircular.Attachments = data.Attachments;
    this.incomingcircular.Status = data.Status;
  }

  async ngOnInit() {
    this.bottonControll();

    this.bsConfig = Object.assign({}, { containerClass: this.colorTheme });
    // tinymce.init({
    //   //skin_url: '/skins' // Or loaded from your environments config
    //   selector: 'textarea',
    //   directionality: 'rtl',
    //   language: 'ar'
    // });

  }
  public tinyMceSettings = {
    skin_url: 'assets/tinymce/skins/lightgray',
    inline: false,
    statusbar: false,
    browser_spellcheck: true,
    height: 320,
    plugins: 'fullscreen',
  };


  ngAfterViewInit() {

  }

  closemodal() {
    this.modalService.hide(1);
    setTimeout(function () { location.reload(); }, 1000);
  }


  initPage() {
    this.incomingcircular.CircularID = 0
    this.incomingcircular.ReferenceNumber = '';
    this.incomingcircular.Title = '';
    this.incomingcircular.SourceOU = this.currrentUser.department;
    this.incomingcircular.SourceName = this.currrentUser.username;
    this.incomingcircular.DestinationOU = [];
    // this.incomingcircular.DestinationUsername = [];
    this.incomingcircular.ApproverName = 0;
    this.incomingcircular.ApproverDepartment = 0;
    this.incomingcircular.Details = '';
    this.incomingcircular.Priority = '';
    this.incomingcircular.Comments = '';
    this.incomingcircular.Attachments = [];
    this.incomingcircular.AttachmentName = '';
    this.incomingcircular.DeleteFlag = '';
    this.incomingcircular.CreatedBy = this.currrentUser.id;
    this.incomingcircular.UpdatedBy = '';
    this.incomingcircular.CreatedDateTime = new Date();
    this.incomingcircular.UpdatedDateTime = '';
    this.incomingcircular.Status = 0;
  }

  Attachments(event) {
    this.img_file = event.target.files;
    for (var i = 0; i < this.img_file.length; i++) {
      this.attachmentFiles.push(this.img_file[i]);
      this.attachments.push({ 'AttachmentGuid': 0, 'AttachmentsName': this.img_file[i].name, 'CircularID': '' });
    }
    this.incomingcircular.Attachments = this.attachments;
  }
  selectChange(data) {
    this.incomingcircular.DestinationOU;
  }

  deleteAttachment(index) {
    this.attachments.splice(index, 1);
    // if (this.attachments.length == 0) {
    //   this.img_file = [];
    // }
  }


  prepareData() {
    this.createCircular.CreatedDateTime = this.incomingcircular.CreatedDateTime;
    if (this.DestinationDepartmentId.length) {
      this.DestinationDepartmentId.forEach(data => {
        this.createCircular.DestinationDepartmentID.push({
          "CircularDestinationDepartmentID": data,
          'CircularDestinationDepartmentName': ''
        });
      });
    }
    this.createCircular.Title = this.incomingcircular.Title;
    this.createCircular.SourceOU = this.currrentUser.department;
    this.createCircular.SourceName = this.currrentUser.username;
    this.createCircular.ApproverId = this.incomingcircular.ApproverName;
    this.createCircular.ApproverDepartmentId = this.incomingcircular.ApproverDepartment;
    this.createCircular.Details = this.incomingcircular.Details;
    this.createCircular.Priority = this.incomingcircular.Priority;
    this.createCircular.Attachments = this.incomingcircular.Attachments;
    this.createCircular.CreatedBy = this.currrentUser.id;
    //this.createMemo.Action = this.memoModel.Status+'';
    this.createCircular.Comments = this.incomingcircular.Comments;



    return this.createCircular;
  }

  validateForm() {
    var flag = true;
    var destination = (this.incomingcircular.DestinationOU) ? (this.incomingcircular.DestinationOU.length > 0) : false;
    //var Keywords = (this.incomingcircular.Keywords) ? (this.incomingcircular.Keywords.length > 0) : false;
    //var username = (this.incomingcircular.DestinationUsername) ? (this.incomingcircular.DestinationUsername.length > 0) : false;

    if (destination && this.incomingcircular.Title && this.incomingcircular.ApproverName
      && this.incomingcircular.ApproverDepartment && this.incomingcircular.Details
      && this.incomingcircular.Priority && this.incomingcircular.Attachments.length > 0) {
      flag = false;
    }
    return flag;
  }


  createBtnShow = false;
  editBtnShow = false;
  viewBtnShow = false;
  approverBtn = false;
  receiverBtn = false;
  deleteBtn = false;
  creatorBtn = false;
  draftBtn = false;
  cloneBtn = false;
  id = '';



  bottonControll() {
    if (this.screenStatus == 'Create') {
      this.createBtnShow = true;
    } else if (this.screenStatus == 'Edit') {
      this.editBtnShow = true;
    } else if (this.screenStatus == 'View' && this.incomingcircular.CreatedBy == this.currrentUser.id) {
      this.viewBtnShow = true;
    }
    if (this.incomingcircular.CreatedBy == this.currrentUser.id && this.incomingcircular.Status == 14) {
      this.creatorBtn = true;
    }
    if (this.incomingcircular.CreatedBy == this.currrentUser.id && (this.incomingcircular.Status == 0 || this.incomingcircular.Status == 16)) {
      this.draftBtn = true;
    }
    if (this.screenStatus == 'View' && this.incomingcircular.ApproverName == this.currrentUser.id && this.incomingcircular.Status == 13) {
      this.approverBtn = true;
    }
    // this.incomingcircular.DestinationUsername.forEach(element => {
    //   if (element == this.currrentUser.id && this.incomingcircular.Status == 3) {
    //     this.receiverBtn = true;
    //     this.editBtnShow = false;
    //   }
    // });
    if (this.incomingcircular.CreatedBy == this.currrentUser.id && this.incomingcircular.Status == 12) {
      this.deleteBtn = true;
    }
  }

  async Destination(event) {
    this.DestinationDepartmentId = this.incomingcircular.DestinationOU;
    //await this.getRecvUserList(this.DestinationDepartmentId);
  }


  onChangeDepartment() {
    this.getDestUserList(+this.incomingcircular.ApproverDepartment);
  }


  async getDestUserList(id) {
    let params = [{
      "OrganizationID": id,
      "OrganizationUnits": "string"
    }];
    this.common.getUserList(params).subscribe((data: any) => {
      this.userDestination = data;
    });
  }

  saveCircular(data = '') {
    if (data == 'draft') {
      var requestData = this.prepareData();
      requestData.Action = 'Save';
      this.circularService.saveCircular('Circular', requestData).subscribe(data => {
        console.log(data);
        this.message = "Circular Drafted";
        this.bsModalRef = this.modalService.show(SuccessComponent);
        this.bsModalRef.content.message = this.message;
        //location.reload();
      });
    } else {
      if (this.incomingcircular.Status == 12 || this.incomingcircular.Status == 16) {
        requestData = this.prepareData();
        requestData.Action = 'Submit';
        requestData['DeleteFlag'] = true;
        requestData['UpdatedBy'] = this.incomingcircular.CreatedBy;
        requestData['UpdatedDateTime'] = new Date();
        requestData['CircularID'] = this.incomingcircular.CircularID;

        this.circularService.updateCircular('Circular', this.incomingcircular.CircularID, requestData).subscribe(data => {
          if (this.screenStatus == 'Create') {

            this.message = "Circular Saved Successfully";
            this.bsModalRef = this.modalService.show(SuccessComponent);
            this.bsModalRef.content.message = this.message;
            this.bsModalRef.content.screenStatus = this.screenStatus;
          } else {
            this.message = "Circular Updated Successfully";
            this.bsModalRef = this.modalService.show(SuccessComponent);
            this.bsModalRef.content.message = this.message;
            //location.reload();
          }
        });
      } else {
        requestData = this.prepareData();
        requestData.Action = 'Submit';
        console.log(requestData);
        this.circularService.saveCircular('Circular', requestData).subscribe(data => {
          console.log(data);
          if (this.screenStatus == 'Create') {
            this.message = "Circular Saved Successfully";
            this.bsModalRef = this.modalService.show(SuccessComponent);
            this.bsModalRef.content.message = this.message;
            this.bsModalRef.content.screenStatus = this.screenStatus;
          } else {
            this.message = "Circular Updated Successfully";
            this.bsModalRef = this.modalService.show(SuccessComponent);
            this.bsModalRef.content.message = this.message;
            //location.reload();
          }
        });
      }
    }
  }


  statusChange(status: any, dialog) {
    var data = this.formatPatch(status, 'Action')
    this.commonMes = status;
    this.circularService.statusChange('Circular', this.incomingcircular.CircularID, data).subscribe(data => {
      //this.message = 'Memo '+status+'d';
      if (status == 'ReturnForInfo') {
        this.message = "Circular Resubmitted Successfully";
      } else if (status == 'Approve') {
        this.message = "Circular Approved Successfully ";
      } else if (status == 'Reject') {
        this.message = "Circular Rejected Successfully";
      } else if (status == 'Close') {
        this.message = "Circular Closed Successfully";
      } else {
        this.message = 'Circular ' + status + 'd Successfully';
      }
      //that.modalService.show(that.template);
      this.modalService.show(this.template);
      this.loadData(data['CircularId'], this.currrentUser.id);
      //location.reload();

    });

  }

  popup(status: any) {
    this.bsModalRef = this.modalService.show(ModalComponent);
    this.bsModalRef.content.status = status;
    this.bsModalRef.content.fromScreen = 'Circular';
    this.bsModalRef.content.memoid = this.incomingcircular.CircularID;
  }

  // approve() {
  //   this.memoservice.statusChange('memo', this.id, data).subscribe(data => {
  //     console.log('approved' + data);
  //   });
  // }

  // escalate() {
  //   var data = this.formatPatch('escalate', 'Status')
  //   this.memoservice.statusChange('memo', this.id, data).subscribe(data => {
  //     console.log('escalated' + data);
  //   });
  // }

  // reject() {
  //   var data = this.formatPatch('reject', 'Status')
  //   this.memoservice.statusChange('memo', this.id, data).subscribe(data => {
  //     console.log('rejected' + data);
  //   });
  // }
  returnForInfo() {

  }
  clone() {
    this.saveCircular();
  }
  downloadPdf() {

  }
  // shareMemo() {

  //   this.bsModalRef = this.modalService.show(ModalComponent);
  //   this.bsModalRef.content.status = 'Share Memo';
  //   this.bsModalRef.content.memoid = this.incomingcircular.MemoID;

  // }
  print() {
    this.circularService.printCircular('Circular/Download', this.incomingcircular.CircularID).subscribe(data => {
    });
  }
  delete(id) {
    this.circularService.deleteCircular('Circular', this.incomingcircular.CircularID).subscribe(data => {
    });

  }

  // close() {
  //   var data = this.formatPatch('close', 'Status')
  //   this.memoservice.statusChange('memo', this.id, data).subscribe(data => {
  //     console.log('closed' + data);
  //   });
  // }

  // redirect() {
  //   var data = this.formatPatch('redirect', 'Status')
  //   this.memoservice.statusChange('memo', this.id, data).subscribe(data => {
  //     console.log('redirected' + data);
  //   });
  // }

  formatPatch(val, path) {
    var data = [{
      "value": val,
      "path": path,
      "op": "replace"
    }, {
      "value": this.currrentUser.id,
      "path": "UpdatedBy",
      "op": "replace"
    }, {
      "value": new Date(),
      "path": "UpdatedDateTime",
      "op": "replace"
    }, {
      "value": this.incomingcircular.Comments,
      "path": "Comments",
      "op": "replace"
    }];
    return data;
  }

  hisLog(status) {
    if (status == 'Submit' || status == 'Reject' || status == 'Redirect') {
      return status + 'ed';
    } else {
      return status + 'd';
    }
  }
}


