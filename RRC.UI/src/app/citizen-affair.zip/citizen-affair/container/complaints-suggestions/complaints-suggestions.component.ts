import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { CommonService } from 'src/app/common.service';
import { BsDatepickerConfig } from 'ngx-bootstrap';
import { CitizenAffairService } from '../../citizen-affair.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ModalComponent } from '../../../modal/modalcomponent/modal.component';
import { SuccessComponent } from '../../../modal/success-popup/success.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-complaints-suggestions',
  templateUrl: './complaints-suggestions.component.html',
  styleUrls: ['./complaints-suggestions.component.scss']
})
export class ComplaintSuggestionComponent implements OnInit {
  bsConfig: Partial<BsDatepickerConfig>;
  @ViewChild('profile_upload')  profile_upload:ElementRef
  requestTypes=['Field visit Report','Personal Report'];
  requestType = '';
  screenStatus = 'Create';
  displayStatus : any;
  url: string | ArrayBuffer;
  complaint  :any= {
    CAComplaintsuggestionId : 0,
    CreationDate : '',
    Source : '',
    ReferenceNumber : '',
    Type : 'Complaint',
    Subject : '',
    Details : '',
    RequestCreatedBy : '',
    MailId : '',
    PhoneNumber : '',
    Status : '',
    CreatedDateTime: new Date(),
    CreatedBy : '',
    Comments : '',
    Action : '',
    HistoryLog : []
    
  }
  currrentUser: any = JSON.parse(localStorage.getItem('User'));
  message : any;
  ComplaintData : any= {};
  bsModalRef: BsModalRef;
  constructor(private common: CommonService,private modalService: BsModalService,public citizenService : CitizenAffairService,
    public router: Router, route: ActivatedRoute) { 
    this.common.breadscrumChange('Citizen Affair','Complaints/Suggestions','');
    route.url.subscribe(() => {
      console.log(route.snapshot.data);
      this.screenStatus = route.snapshot.data.title;
    });
    route.params.subscribe(param => {
      var id = +param.id;
      var id = +param.id;
      if (id > 0)
        this.loadData(id, this.currrentUser.id);
    });
    this.citizenService.getComplaintSuggestion('CitizenAffairComplaintSuggestions', 0, 0).subscribe((data: any) => {
      //this.department = data.OrganizationList;
    });
    if(this.screenStatus == 'Create'){
      this.displayStatus = 'CREATION';
    }
    if(this.screenStatus == 'View'){
      this.displayStatus = 'VIEW';
    }
    if(this.screenStatus == 'Edit'){
      this.displayStatus = 'EDIT';
    }
  }

  ngOnInit() {
    this.bottonControll();
  }

  async loadData(id, userid) {
    await this.citizenService.getComplaintSuggestion('CitizenAffairComplaintSuggestions', id, userid).subscribe((data: any) => {
     // this.circularData = data;
      // if (this.screenStatus == 'View' || this.screenStatus == 'Edit') {
      //   let that = this;
      //   this.status = this.circularData.M_LookupsList;
      //   var date = this.incomingcircular.CreatedDateTime;
      //   this.incomingcircular.CreatedDateTime = new Date(date);
      //   this.setData(this.circularData);
      //   this.bottonControll();
      // } else {
      //   this.initPage();
      //   this.bottonControll();
      // }
    });
  }

  prepareData(){
    this.ComplaintData = {};
    if(this.complaint.RequestCreatedBy == 'Anonymous'){
      this.complaint.MailId = "";
      this.complaint.PhoneNumber = "";
    }

    this.ComplaintData = this.complaint;

    return this.ComplaintData;
  }
  
  validateForm(){
    var flag = false;
    // var destination = (this.incomingcircular.DestinationOU) ? (this.incomingcircular.DestinationOU.length > 0) : false;
    
    // if (destination && this.incomingcircular.Title && this.incomingcircular.ApproverName
    //   && this.incomingcircular.ApproverDepartment && this.incomingcircular.Details
    //   && this.incomingcircular.Priority && this.incomingcircular.Attachments.length > 0) {
    //   flag = false;
    // }
    return flag;
  }
  submitBtn = false;
  assignBtn = false;
  assigntomeBtn = false;
  closeBtn = false;
  bottonControll() {
    
    if (this.screenStatus == 'Create') {
      this.submitBtn = true;
    } 
    // if (this.complaint.CreatedBy == this.currrentUser.id && (this.complaint.Status == 0 || this.incomingcircular.Status == 16)) {
    //   this.draftBtn = true;
    // }
    // if (this.screenStatus == 'View' && this.incomingcircular.ApproverName == this.currrentUser.id && this.incomingcircular.Status == 13) {
    //   this.approverBtn = true;
    // }
    
    // if (this.incomingcircular.CreatedBy == this.currrentUser.id && this.incomingcircular.Status == 12) {
    //   this.deleteBtn = true;
    // }
  }
  submit(){
    var requestData = this.prepareData();
      requestData.Action = 'Submit';
      this.citizenService.saveComplaintSuggestion('CitizenAffairComplaintSuggestions', requestData).subscribe(data => {
        console.log(data);
        this.message = "Complain Suggestion Submitted";
        this.bsModalRef = this.modalService.show(SuccessComponent);
        this.bsModalRef.content.message = this.message;
      });
  }

}
