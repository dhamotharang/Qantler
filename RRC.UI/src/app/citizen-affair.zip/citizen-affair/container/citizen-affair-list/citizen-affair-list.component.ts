import { Component, OnInit, ViewChild, ElementRef, TemplateRef } from '@angular/core';
import Chart from 'chart.js';
import { CommonService } from '../../../common.service';
import { data } from './data';
import { Router } from '@angular/router';
import { BsDatepickerConfig } from 'ngx-bootstrap';

@Component({
  selector: 'app-citizen-affair-list',
  templateUrl: './citizen-affair-list.component.html',
  styleUrls: ['./citizen-affair-list.component.scss','../../../task/container/task-dashboard/task-dashboard.component.scss']
})
export class CitizenAffairListComponent implements OnInit {
  @ViewChild('actionTemplate') actionTemplate: TemplateRef<any>;
  @ViewChild('pieChart') pieChart: ElementRef;
  @ViewChild('barChart') barChart: ElementRef;
  public rows: Array<any> = [];
  public columns: Array<any> = [];
  public cardDetails = [
    {
      'image': 'assets/citizen-affair/tabs.png',
      'count': 10,
      'name': 'New',
      'progress': 50
    },
    {
      'image': 'assets/citizen-affair/information.png',
      'count': 20,
      'name': 'Need more Info',
      'progress': 50
    },
    {
      'image': 'assets/citizen-affair/close.png',
      'count': 50,
      'name': 'Closed',
      'progress': 50
    }
  ];
  userList: Object;
  priorityList: string[];
  public config: any = {
    paging: true,
    page: 1,
    maxSize: 10
    // sorting: { columns: this.columns },
    // filtering: { filterString: '' },
    // className: ['table-striped', 'table-bordered', 'm-b-0']
  };
  masterData = new data;
  status = this.masterData.data.status;
  taskList = this.masterData.data.Collection;
  count = this.masterData.data.Count;
  bsConfig: Partial<BsDatepickerConfig>;

  constructor(private common: CommonService,public router:Router) {
    this.getUserList([]);
    this.rows = this.taskList;
    this.priorityList = this.common.priorityList;
    this.common.breadscrumChange('Citizen Affair','List Page','');
    this.common.topBanner(true,'Citizen Affair List','+ CREATE REQUEST','citizen-affair-create');
  }

  ngOnInit() {
    this.columns = [
      { name: 'Ref ID', prop: 'referenceNumber' },
      { name: 'Status', prop: 'Status' },
      { name: 'Request Type', prop: 'requestType' },
      { name: 'Request Date', prop: 'date' },
      { name: 'Personal/ Location Name', prop: 'personalName' },
      { name: 'Phone Number', prop: 'phoneNumber' },
      { name: 'Action', prop: '', cellTemplate: this.actionTemplate },
    ];
    this.pieChart.nativeElement;
    var piectx = document.getElementById('pieChart');
    var barctx = document.getElementById('barChart');

    var myChart = new Chart(barctx, {
      type: 'horizontalBar',
      data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green'],
        datasets: [{
          label: 'red',
          data: [12, 19, 3, 5],
          backgroundColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)'
          ],
          borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)'
          ],
          borderWidth: 1
        }, {
          label: 'Blue',backgroundColor: 'rgba(54, 162, 235, 1)', borderWidth: 1, borderColor: 'rgba(54, 162, 235, 1)',
        },
        { label: 'Yellow', backgroundColor: 'rgba(255, 206, 86, 1)', borderWidth: 1, borderColor: 'rgba(255, 206, 86, 1)', },
        { label: 'Green', backgroundColor: 'rgba(75, 192, 192, 1)', borderWidth: 1, borderColor: 'rgba(75, 192, 192, 1)' },
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scaleShowValues: true,
        legend: {
          display: true,
          position: 'bottom',
          fullWidth: true
        },
        scales: {
          xAxes: [{
            // barThickness : 45,
            // barPercentage: 1.0,
            // categoryPercentage: 1.0,
            categoryPercentage: 1.0,
            barPercentage: 1.0,
            ticks: {
              // stepSize: 1,
              // min: 0,
              autoSkip: false
            },
            gridLines: {
              display: true,
              //color: "rgba(0, 0, 0, 0)",
            }
          }],
          // stacked: false,
          // beginAtZero: true,
          // scaleLabel: {
          //     labelString: 'Month'
          // },
          // ticks: {
          //     stepSize: 1,
          //     min: 0,
          //     autoSkip: false
          // }
          yAxes: [{
            ticks: {
              display: false,
              autoSkip: false
            },
            gridLines: {
              display: false,
              color: "rgba(0, 0, 0, 0)",
            }
          }]
        }
      }
    });
    var myChart = new Chart(piectx, {
      type: 'pie',
      data: {
        labels: ['Red', 'Yellow', 'Green', 'Purple'],
        datasets: [{
          label: '# of Votes',
          data: [12, 14, 3, 5, 3],
          backgroundColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)'
          ],
          borderColor: [
            'rgba(255, 255, 255, 1)',
            'rgba(255, 255, 255, 1)',
            'rgba(255, 255, 255, 1)',
            'rgba(255, 255, 255, 1)'
          ],
          borderWidth: 10
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        // layout: {
        //   padding: {
        //     left: 50,
        //     right: 50,
        //     top: 0,
        //     bottom: 0
        //   }
        // },
        legend: {
          display: true,
          position: 'bottom',
          fullWidth: true
        },
        scales: {
          xAxes: [{
            ticks: {
              display: false
            },
            gridLines: {
              display: false,
              color: "rgba(0, 0, 0, 0)",

            }
          }],
          yAxes: [{
            ticks: {
              display: false
            },
            gridLines: {
              display: false,
              color: "rgba(0, 0, 0, 0)",
            }
          }]
        }
      }
    });
  }

  viewData(type,value){
    if(type=='edit'){
      this.router.navigate(['pages/citizen-affair-edit/' + value.citizenAffairID]);
    }else{
      this.router.navigate(['pages/citizen-affair-view/' + value.citizenAffairID]);
    }
  }

  async getUserList(data) {
    this.userList = this.common.getUserList(data).subscribe(list => {
      this.userList = list;
    });
  }
}
