export class data {
    data = {
        status: [
            { id: 1, name: 'Draft' },
            { id: 2, name: 'Waiting for Approval' },
            { id: 3, name: 'Under Progress' },
            { id: 4, name: 'Rejected' },
            { id: 5, name: 'Pending for Resubmission' },
            { id: 6, name: 'Closed' }
        ],
        Collection: [
            {
                citizenAffairID: 1,
                referenceNumber: '1215', Title: 'sample tille',
                requestType: null,
                Status: 'draft',
                date: '12-02-2019',
                personalName:'beer',
                phoneNumber:'8489989300'
            }, {
                citizenAffairID: 1,
                referenceNumber: '1215', Title: 'sample tille',
                requestType: null,
                Status: 'draft',
                date: '12-02-2019',
                personalName:'beer',
                phoneNumber:'8489989300'
            }, {
                citizenAffairID: 1,
                referenceNumber: '1215', Title: 'sample tille',
                requestType: null,
                Status: 'draft',
                date: '12-02-2019',
                personalName:'beer',
                phoneNumber:'8489989300'
            },
        ],
        Count: 3,
        Organization: null,
        M_OrganizationList: null,
        M_LookupsList: null
    }
}