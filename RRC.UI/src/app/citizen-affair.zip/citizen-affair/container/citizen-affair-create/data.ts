export class citizenData {
    department = [
        {
            name: 'dept1',
            id: 1
        },
        {
            name: 'dept2',
            id: 2
        },
        {
            name: 'dept3',
            id: 3
        }
    ]
    data = {
        CitizenAffairID: 1,
        CreationDate: 12 - 2 - 2019,
        SourceOU: "beer",
        SourceName: "beer",
        Status: "status",
        ReferenceNumber: "01-25dfds",
        RequestType: "empty",
        Date: 12 - 2 - 2019,
        RequestLocation: 'chennai',
        RequestedBy: 'sheik',
        PersonalName: 'beerali',
        PersonalEmployer: 'mohi',
        Destination: 'chennai',
        MonthlySalary: '12000',
        PersonalEmiratesID: 'fsd',
        Maritalstatus: 'single',
        NoofChildrens: '0',
        PersonalPhoneNumber: '8489989300',
        PersonalEmirates: 'madurai',
        PersonalCity: 'kayathar',
        Age: '23',
        ReportObjective: 'dgfh fsgg fsrfgrf sdf',
        Recommandation: 'sdfgdfsgs',
        VisitObjective: 'sgdfgdfg',
        FindingNotes: 'ghfdsafj',
        ForWhom: 'personal',
        EmiratesID: '1123',
        Name: 'sheik',
        PhoneNumber: '8489989300',
        ForWhomCity: 'amdurai',
        LocationName: 'madurai',
        Emirates: 'no',
        City: 'chennai',
        ApproverId: '12fd',
        ApproverDepartmentId: '12',
        NotifyUpponApproval: 'internalrequestor',
        PersonId: '12',
        PersonDepartmentId: '23',
        EmailId: 'mbrmhmmd@gmail.com',
        CreatedBy: 'beer',
        CreatedDateTime: 12 - 2 - 2019,
        Action: '',
        Comments: '',
        Attachments: [
            {
                AttachmentGuid: '',
                AttachmentsName: '',
                CitizenAffairID: '',
            }
        ],
        PhotoAttachments: [
            {
                AttachmentGuid: '',
                AttachmentsName: '',
                CitizenAffairID: '',
            }
        ],
        OrganizationList: '',
        M_LookupList: '',
        HistoryLog: [
            {
                HistoryID: 0,
                CitizenAffairID: 0,
                Action: '',
                Comments: '',
                ActionBy: '',
                ActionDateTime: 12 - 2 - 2019,
            }
        ]

    }
}