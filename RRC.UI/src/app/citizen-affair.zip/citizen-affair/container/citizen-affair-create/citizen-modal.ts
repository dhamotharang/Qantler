export class CitizenCreateModal {
    CitizenAffairID: Number
    CreationDate: Date
    SourceOU: String
    SourceName: String
    Status: string
    ReferenceNumber: String
    RequestType: string
    Date: Date
    RequestLocation: String
    RequestedBy: String
    PersonalName: String
    PersonalEmployer: String
    Destination: String
    MonthlySalary: String
    PersonalEmiratesID: String
    Maritalstatus: String
    NoofChildrens: string
    PersonalPhoneNumber: string
    PersonalEmirates: string
    PersonalCity: string
    Age: String
    ReportObjective: String
    Recommandation: String
    VisitObjective: String
    FindingNotes: String
    ForWhom: String
    EmiratesID: string
    Name: String
    PhoneNumber: String
    ForWhomCity: String
    LocationName: String
    Emirates: string
    City: String
    ApproverId: Number
    ApproverDepartmentId: Number
    NotifyUpponApproval: String
    PersonId: Number
    PersonDepartmentId: Number
    EmailId: String
    CreatedBy: Number
    CreatedDateTime: Date
    Action: String
    Comments: String
    Attachments: [
        {
            AttachmentGuid: string
            AttachmentsName: string
            CitizenAffairID: string
        }
    ]
    PhotoAttachments: [
        {
            AttachmentGuid: string
            AttachmentsName: string
            CitizenAffairID: string
        }
    ]
    OrganizationList: string
    M_LookupList: string
    HistoryLog: [
        {
            HistoryID: number
            CitizenAffairID: number
            Action: string
            Comments: string
            ActionBy: String
            ActionDateTime: Date
        }
    ]

}