import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { CommonService } from 'src/app/common.service';
import { CitizenCreateModal } from './citizen-modal';
import { CitizenAffairService } from '../../citizen-affair.service';
import { ActivatedRoute, Router } from '@angular/router';
import { citizenData } from './data';
@Component({
  selector: 'app-citizen-affair-create',
  templateUrl: './citizen-affair-create.component.html',
  styleUrls: ['./citizen-affair-create.component.scss']
})
export class CitizenAffairCreateComponent implements OnInit {
  @ViewChild('profile_upload') profile_upload: ElementRef
  requestTypes = ['Field visit Report', 'Personal Report'];
  requestType = '';
  url: string | ArrayBuffer;
  citizenCreateModal: CitizenCreateModal = new CitizenCreateModal();
  Data: citizenData = new citizenData();
  screenStatus: any = "Create";
  person_UserList: Promise<void>;
  approver_UserList: Promise<void>;
  userList: Promise<void>;

  // constructor
  constructor(private common: CommonService, public service: CitizenAffairService,
    public router: Router, route: ActivatedRoute) {
    this.common.breadscrumChange('Citizen Affair', 'Personal Report/Field Visit Report Creation', '');

    route.url.subscribe(() => {
      console.log(route.snapshot.data);
      this.screenStatus = route.snapshot.data.title;
    });
    route.params.subscribe(param => {
      var id = +param.id;
      if (id > 0) {
        // this.service.getDataById('CitizenAffair', id, this.common.currrentUser.id).subscribe((res: any) => {
        //   this.setData(res);
        // });
        this.setData(this.Data.data);
      }
    });
  }

  // ngOninit
  ngOnInit() {
    this.getUserList('');
  }

  async getUserList(id,type='') {
    var type = type,
    param = [],
    user:any;
   
    if (id !='') {
      param = [{
        "OrganizationID": id,
        "OrganizationUnits": "string"
      }];
    }
    this.common.getUserList(param).subscribe((res:any)=>{
      if(type=='person'){
        this.person_UserList = res;
      }else if(type=='approver'){
        this.approver_UserList = res;
      }else{
        this.userList = res;
      }
    });
  }

  personDeptChange() {
    this.getUserList(this.citizenCreateModal.PersonDepartmentId,'person');
  }

  approverDeptChange() {
    this.getUserList(this.citizenCreateModal.ApproverDepartmentId,'approver');
  }

  clickProfile() {
    this.profile_upload.nativeElement.click();
  }

  profileLoad(e) {
    if (e.target.files && e.target.files[0]) {
      var reader = new FileReader();

      reader.onload = (e: ProgressEvent) => {
        this.url = (<FileReader>e.target).result;
      }
      reader.readAsDataURL(e.target.files[0]);
    }
  }

  setData(data) {
    this.citizenCreateModal.SourceOU = data.SourceOU;
    this.citizenCreateModal.CitizenAffairID = 1,
      this.citizenCreateModal.CreationDate = new Date(),
      this.citizenCreateModal.SourceOU = "beer",
      this.citizenCreateModal.SourceName = "beer",
      this.citizenCreateModal.Status = "status",
      this.citizenCreateModal.ReferenceNumber = "01-25dfds",
      this.citizenCreateModal.RequestType = "empty",
      this.citizenCreateModal.Date = new Date(),
      this.citizenCreateModal.RequestLocation = 'chennai',
      this.citizenCreateModal.RequestedBy = 'sheik',
      this.citizenCreateModal.PersonalName = 'beerali',
      this.citizenCreateModal.PersonalEmployer = 'mohi',
      this.citizenCreateModal.Destination = 'chennai',
      this.citizenCreateModal.MonthlySalary = '12000',
      this.citizenCreateModal.PersonalEmiratesID = 'fsd',
      this.citizenCreateModal.Maritalstatus = 'single',
      this.citizenCreateModal.NoofChildrens = '0',
      this.citizenCreateModal.PersonalPhoneNumber = '8489989300',
      this.citizenCreateModal.PersonalEmirates = 'madurai',
      this.citizenCreateModal.PersonalCity = 'kayathar',
      this.citizenCreateModal.Age = '23',
      this.citizenCreateModal.ReportObjective = 'dgfh fsgg fsrfgrf sdf',
      this.citizenCreateModal.Recommandation = 'sdfgdfsgs',
      this.citizenCreateModal.VisitObjective = 'sgdfgdfg',
      this.citizenCreateModal.FindingNotes = 'ghfdsafj',
      this.citizenCreateModal.ForWhom = 'personal',
      this.citizenCreateModal.EmiratesID = '1123',
      this.citizenCreateModal.Name = 'sheik',
      this.citizenCreateModal.PhoneNumber = '8489989300',
      this.citizenCreateModal.ForWhomCity = 'amdurai',
      this.citizenCreateModal.LocationName = 'madurai',
      this.citizenCreateModal.Emirates = 'no',
      this.citizenCreateModal.City = 'chennai',
      this.citizenCreateModal.ApproverId = 0,
      this.citizenCreateModal.ApproverDepartmentId = 0,
      this.citizenCreateModal.NotifyUpponApproval = 'internalrequestor',
      this.citizenCreateModal.PersonId = 0,
      this.citizenCreateModal.PersonDepartmentId = 0,
      this.citizenCreateModal.EmailId = 'mbrmhmmd@gmail.com',
      this.citizenCreateModal.CreatedBy = 0,
      this.citizenCreateModal.CreatedDateTime = new Date(),
      this.citizenCreateModal.Action = '',
      this.citizenCreateModal.Comments = ''
  }


  saveForm(type) {
    var param = this.citizenCreateModal;
    if (type)
      this.service.saveForm('CitizenAffair', param);
  }

  patchCall(type) {
    var param = this.common.formatPatchData(type, 'action');
    this.common.patch('CitizenAffair', param, this.citizenCreateModal).subscribe(res => {
      console.log(res);
    });
  }


}
