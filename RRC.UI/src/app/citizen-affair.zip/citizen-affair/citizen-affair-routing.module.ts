import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CitizenAffairTemplateComponent } from './components/citizen-affair-template.component';
import { CitizenAffairListComponent } from './container/citizen-affair-list/citizen-affair-list.component';
import { CitizenAffairCreateComponent } from './container/citizen-affair-create/citizen-affair-create.component';
import { ComplaintSuggestionComponent } from './container/complaints-suggestions/complaints-suggestions.component';

const routes: Routes = [{
  path: '', component: CitizenAffairTemplateComponent,
  children: [
    { path: 'citizen-affair-list', component:CitizenAffairListComponent },
    { path: 'citizen-affair-create', component:CitizenAffairCreateComponent },
    { path: 'complaint-suggestion', component: ComplaintSuggestionComponent, data: {}},
    { path: 'citizen-affair-view/:id', component: CitizenAffairCreateComponent, data: { title: 'View' } },
    { path: 'citizen-affair-edit/:id', component: CitizenAffairCreateComponent, data: { title: 'Edit' } },
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CitizenAffairRoutingModule { }
