import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-citizen-affair-template',
  templateUrl: './citizen-affair-template.component.html'
})
export class CitizenAffairTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
