import { NgModule } from '@angular/core';
import { CitizenAffairTemplateComponent } from './components/citizen-affair-template.component';
import { CitizenAffairListComponent } from './container/citizen-affair-list/citizen-affair-list.component';
// import { CommonPageModule } from '../commonpage.module';
import { CitizenAffairCreateComponent } from './container/citizen-affair-create/citizen-affair-create.component';
import { ComplaintSuggestionComponent } from './container/complaints-suggestions/complaints-suggestions.component';
import { CitizenAffairRoutingModule } from './citizen-affair-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { BsDatepickerModule, ModalModule, AccordionModule } from 'ngx-bootstrap';
import { NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxEditorModule } from 'ngx-editor';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgxPaginationModule } from 'ngx-pagination';
import { TagInputModule } from 'ngx-chips';
import { EditorModule } from '@tinymce/tinymce-angular';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgxTinymceModule } from 'ngx-tinymce';
import { NgSelectModule } from '@ng-select/ng-select';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { TypeaheadModule } from 'ngx-bootstrap';

import { CommonModule } from '@angular/common';
@NgModule({
  declarations: [CitizenAffairTemplateComponent,CitizenAffairListComponent, CitizenAffairCreateComponent,ComplaintSuggestionComponent],
  imports: [
    // CommonPageModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SelectDropDownModule,
    BsDatepickerModule.forRoot(),
    NgbPaginationModule,
    NgxEditorModule,
    NgxDatatableModule,
    NgxPaginationModule,
    NgbPaginationModule,
    TagInputModule,
    EditorModule,
    ModalModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    NgxTinymceModule.forRoot({
      baseURL: './assets/tinymce/',
    }),
    NgSelectModule,
    AccordionModule.forRoot(),
    PdfViewerModule,
    TypeaheadModule,
    CitizenAffairRoutingModule
  ]
})
export class CitizenAffairModule { }
