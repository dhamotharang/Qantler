import { Injectable } from '@angular/core';
import { EndPointService } from '../api/endpoint.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CitizenAffairService {

  constructor(public endpoint: EndPointService, public httpClient: HttpClient) { }

  saveForm(APIString, data) {
    return this.httpClient.post(this.endpoint.apiHostingURL + '/' + APIString, data);
  }

  saveComplaintSuggestion(APIString, data) {
    return this.httpClient.post(this.endpoint.apiHostingURL + '/' + APIString, data);
  }

  getDataById(APIString, id, userId) {
    return this.httpClient.get(this.endpoint.apiHostingURL + '/' + APIString + '/' + id + '/' + userId);
  }
  getComplaintSuggestion(APIString, id, userId) {
    return this.httpClient.get(this.endpoint.apiHostingURL + '/' + APIString + '/' + id + '?Userid=' + userId);
  }
}
